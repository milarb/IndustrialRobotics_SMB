
close all
clear all

axis([-4 4 -4 4 -4 4]);
view(3);
hold on
r = TM12

