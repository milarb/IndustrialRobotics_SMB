classdef NewSystem
    %SYSTEM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        UR3
        TM12
        ExtraUR3
        gui
        Items
        PlaceLocation
        TablePoints
        BarrierPoints
    end
    
    methods
        function self = NewSystem(System)
            % self.UR3 = System.UR3;
            % self.TM12 = System.TM12;
            % self.Items = System.Items;
            % self.PlaceLocation = System.PlaceLocation;
            % self.TablePoints = System.TablePoints;
            % self.BarrierPoints = System.BarrierPoints;
        end

    end
end

