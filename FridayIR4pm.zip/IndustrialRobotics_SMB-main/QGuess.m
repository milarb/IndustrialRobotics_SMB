r = UR3(transl(-1.5,0.3, 0.7))
r.model.teach();

%%

b = TM12(transl(-0.8,0.8, 0.7))
b.model.teach();