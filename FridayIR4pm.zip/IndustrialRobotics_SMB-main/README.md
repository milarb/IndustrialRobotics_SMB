# IndustrialRobotics_SMB
Industrial robotics lab assignment 2 SPR2023
