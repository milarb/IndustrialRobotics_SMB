r = UR3()
r.model.getpos
