
close all
clear all


axis([-2 2 -2 2 -2 2]);
view(3);
hold on
r = TM12

q = [0 0 0 0 0 0];

r.model.teach(q)



